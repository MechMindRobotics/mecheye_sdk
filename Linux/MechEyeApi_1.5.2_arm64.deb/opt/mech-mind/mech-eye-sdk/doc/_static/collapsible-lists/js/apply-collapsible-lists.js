$(document).ready(function() {
    CollapsibleLists.apply();
});
