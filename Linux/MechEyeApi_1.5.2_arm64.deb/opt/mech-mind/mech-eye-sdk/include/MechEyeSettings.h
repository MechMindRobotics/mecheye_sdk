/*******************************************************************************
 *BSD 3-Clause License
 *
 *Copyright (c) 2016-2022, Mech-Mind Robotics
 *All rights reserved.
 *
 *Redistribution and use in source and binary forms, with or without
 *modification, are permitted provided that the following conditions are met:
 *
 *1. Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 *
 *2. Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 *
 *3. Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 *THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#pragma once
#include <vector>
#include "MechEyeDataType.h"

namespace mmind {

namespace api {

/**
 * Settings used for 3D capturing.
 */
struct Scanning3DSettings
{
    /**
     * The exposure time sequence of the camera to capture the 3D images. Multiple exposures
     *will produce a HDR effect.
     * @details Long exposure is often used for scanning dark objects and short exposure is often
     *used for scanning reflective objects. \n
     * @details Getter: @ref MechEyeDevice.getScan3DExposure \n
     * @details Setter: @ref MechEyeDevice.setScan3DExposure \n
     * @note Exposure unit: ms \n
     *  Exposure minimum: 0.1 \n
     *  Exposure maximum: 99 \n
     *  Minimum Vector Size: 1 \n
     *  Maximum Vector Size: 3 \n
     */
    std::vector<double> ExposureSequence;

    /**
     * Camera's gain value during scanning 3D images.
     * @details Gain is an electronic amplification of the image signal. Large gain value is needed
     * only when scanning extremely dark objects. \n
     * @details Getter: @ref MechEyeDevice.getScan3DGain \n
     * @details Setter: @ref MechEyeDevice.setScan3DGain \n
     * @note Minimum: 0 \n
     *       Maximum: 16 \n
     */
    double Gain;

    /**
     * Depth map's ROI along height and width axes in camera coordinate system. Pixels locate out of
     * the ROI will be ignored.
     * @details If @ref ROI.height, @ref ROI.width, @ref ROI.x and @ref ROI.y values are all zero,
     * all pixels will be used.
     * @details Getter: @ref MechEyeDevice.getScan3DROI \n
     * @details Setter: @ref MechEyeDevice.setScan3DROI \n
     * @note  @ref ROI.x must be less than the number of columns in the image. \n
     *        @ref ROI.y must be less than the number of rows in the image. \n
     *        @ref ROI.width must be less than the width of the image. \n
     *        @ref ROI.height must be less than the height of the image. \n
     */
    ROI Scan3DROI;

    /**
     * Depth image's valid range along Z-axis in camera coordinate system.
     * @details Pixels with depth value greater than the @ref DepthRange.upper and less
     * than the @ref DepthRange.lower will be ignored. \n
     * @details Getter: @ref MechEyeDevice.getDepthRange \n
     * @details Setter: @ref MechEyeDevice.setDepthRange \n
     * @note Unit: mm \n
     *       Minimum: 1 \n
     *       Maximum: 5000 \n
     */
    DepthRange DepthRange;
};

/**
 * Settings used for ColorMap capturing.
 */
struct Scanning2DSettings
{
    /**
     * Option for exposure mode.
     */
    enum Scan2DExposureMode {
        Timed, ///< Fixed exposure time, recommended in the stable ambient light conditions.
        Auto,  ///< Automatic exposure time, recommended in unstable ambient light conditions.
        HDR,   ///< Generate images of high dynamic ranges showing more details with multiple
               ///< different exposures.
        Flash, ///< Use projected LED light to light up the projection area.
    };

    /**
     * Option for exposure mode.
     */
    Scan2DExposureMode ExposureMode;

    /**
     * @brief The fixed camera exposure time.
     * @details Only take effect in @ref Timed mode. \n
     * @details Getter: @ref MechEyeDevice.getScan2DExposureTime \n
     * @details Setter: @ref MechEyeDevice.setScan2DExposureTime \n
     * @note Unit: ms \n
     *       Minimum: 0.1 \n
     *       Maximum: 999 \n
     */
    double ExposureTime;

    /**
     * The image sharpen factor.
     * @details Take effect in all @ref Scan2DExposureMode mode. \n
     * @details Use sharpening algorithm to get sharp edge details, it may cause image noise. The
     * higher the value, the higher the image sharpness. \n
     * @details Getter: @ref MechEyeDevice.getScan2DSharpenFactor \n
     * @details Setter: @ref MechEyeDevice.setScan2DSharpenFactor \n
     * @note Minimum: 0 \n
     *       Maximum: 5 \n
     */
    double SharpenFactor;

    /**
     * The expected image gray value.
     * @details Only take effect in @ref Auto mode.
     * @details A smaller value can decrease the brightness of the image, while a larger value can
     * generate a brighter image. \n
     * @details Getter: @ref MechEyeDevice.getScan2DExpectedGrayValue \n
     * @details Setter: @ref MechEyeDevice.setScan2DExpectedGrayValue \n
     * @note Minimum: 0 \n
     *       Maximum: 255 \n
     */
    int ExpectedGrayValue;

    /**
     * Camera's ROI when scanning 2D images \n
     * @details Only take effect in @ref Auto and @ref HDR mode. \n
     * @details Getter: @ref MechEyeDevice.getScan2DROI \n
     * @details Setter: @ref MechEyeDevice.setScan2DROI \n
     * @note @ref ROI.x must be less than the number of columns in the image. \n
     *       @ref ROI.y must be less than the number of rows in the image. \n
     *       @ref ROI.width must be less than the width of the image. \n
     *       @ref ROI.height must be less than the height of the image. \n
     */
    ROI Scan2DROI;

    /**
     * Use gray level transformation algorithm to make the image look more natural.
     * @details Only take effect in @ref HDR mode.
     * @details Getter: @ref MechEyeDevice.getScan2DToneMappingEnable \n
     * @details Setter: @ref MechEyeDevice.setScan2DToneMappingEnable \n
     */
    bool ToneMappingEnable;

    /**
     * A sequence of camera exposures used for HDR capturing.
     * @details Only take effect in @ref HDR mode.
     * @details Getter: @ref MechEyeDevice.getScan2DHDRExposureSequence \n
     * @details Setter: @ref MechEyeDevice.setScan2DHDRExposureSequence \n
     * @note Exposure unit: ms  \n
     *       Exposure minimum: 0.1 \n
     *       Exposure maximum: 999 \n
     *       Minimum Vector Size: 1 \n
     *       Maximum Vector Size: 5 \n
     */
    std::vector<double> HDRExposureSequence;
};

struct PointCloudProcessingSettings
{
    /**
     * Option for cloud outlier filter.
     */
    enum struct CloudOutlierFilterMode {
        Off,    ///< No outlier removal operation. Certain noisy points may exist.
        Normal, ///<  Most outliers are removed. Mild edge erosion might occur under certain
                ///<  circumstances.
        Weak,   ///< Moderate amount of outliers are removed. This mode allows having more accurate
                ///< and more complete edges.
    };

    /**
     * Option for cloud smooth filter.
     */
    enum struct CloudSmoothMode {

        Off,    ///< No smoothing. More details of the point cloud are preserved.
        Normal, ///< Moderate level surface smoothness. Noise is reduced at the expense of
                ///< fine-scale details.
        Weak,   ///< Light level surface smoothness. Noise is reduced at the expense of negligible
                ///< details.
        Strong, ///< Advanced level surface smoothness. Noise is reduced at the expense of
                ///< moderate-scale details.
    };

    /**
     * The signal contrast threshold for effective pixels. Pixels with contrast less
     *than this threshold will be ignored. \n
     * @details A higher value will result in more image noise to be filtered
     *but may also cause the point cloud of dark objects to be removed. \n
     * @details Getter: @ref MechEyeDevice.getFringeContrastThreshold \n
     * @details Setter: @ref MechEyeDevice.setFringeContrastThreshold \n
     * @note Minimum: 0 \n
     *       Maximum: 100 \n
     */
    int FringeContrastThreshold;

    /**
     * The signal minimum threshold for effective pixels. Pixels with intensity less
     * than this threshold will be ignored. \n
     * @details A higher value will result in more image noise to be filtered
     * but may also cause the point cloud of dark objects to be removed. \n
     * @details Getter: @ref MechEyeDevice.getFringeMinThreshold \n
     * @details Setter: @ref MechEyeDevice.setFringeMinThreshold \n
     * @note Minimum: 0 \n
     *       Maximum: 100 \n
     */
    int FringeMinThreshold;

    /**
     * The point cloud outlier removal level. \n
     * @details Getter: @ref MechEyeDevice.getCloudOutlierFilterMode \n
     * @details Setter: @ref MechEyeDevice.setCloudOutlierFilterMode \n
     */
    CloudOutlierFilterMode OutlierFilterMode;

    /**
     * Option for cloud smooth filter. \n
     * @details Getter: @ref MechEyeDevice.getCloudSmoothMode \n
     * @details Setter: @ref MechEyeDevice.setCloudSmoothMode \n
     */
    CloudSmoothMode SmoothMode;
};

/**
 * Settings used for laserColorMap capturing.   \n
 * @note Only used in Mech-Eye Laser product family.    \n
 * @details Getter: @ref MechEyeDevice.getLaserSettings \n
 * @details Setter: @ref MechEyeDevice.setLaserSettings \n
 */
struct LaserSettings
{
    /**
     * Option for laser fringe coding mode.
     */
    enum LaserFringeCodingMode {
        Fast, ///< Fast mode has the minimum capture time.
        High, ///< High mode is slower but produces better depth maps than Fast mode.
    };

    /**
     * Option for laser fringe coding mode.
     */
    LaserFringeCodingMode FringeCodingMode;

    /**
     * The laser scan field of view start position. \n
     * @details @ref FrameRangeStart and @ref FrameRangeEnd work together to determine the laser
     * scan field of view. Use 0~100 to represent all laser projection positions from left to right
     * under the camera's view. The frame range setting must satisfy that @ref FrameRangeEnd is at
     * least 25 larger than @ref FrameRangeStart. \n
     * @note Minimum: 0 \n
     *       Maximum: 100 \n
     *       @ref FrameRangeEnd - @ref FrameRangeStart >= 25 \n
     */
    int FrameRangeStart;

    /**
     * The laser scan field of view end position. \n
     * @details @ref FrameRangeStart and @ref FrameRangeEnd work together to determine the laser
     * scan field of view. Use 0~100 to represent all laser projection positions from left to right
     * under the camera's view. The frame range setting must satisfy that @ref FrameRangeEnd is at
     * least 25 larger than @ref FrameRangeStart. \n
     * @note Minimum: 0 \n
     *       Maximum: 100 \n
     *       @ref FrameRangeEnd - @ref FrameRangeStart >= 25 \n
     */
    int FrameRangeEnd;

    /**
     * Laser's scan partition number. \n
     * @details If the value is more than 1, the scan from start to end will be partitioned into
     * multiple parts. It is recommended to use multiple partition parts for extremely dark objects.
     * \n
     * @note Minimum: 1 \n
     *       Maximum: 4 \n
     */
    int FramePartitionCount;

    /**
     * Laser Power. \n
     * @details High power is often used for scanning dark objects. Low power is often used for
     * scanning reflective objects. \n
     * @note Minimum: 20 \n
     *       Maximum: 100 \n
     */
    int PowerLevel;
};

} // namespace api
} // namespace mmind
