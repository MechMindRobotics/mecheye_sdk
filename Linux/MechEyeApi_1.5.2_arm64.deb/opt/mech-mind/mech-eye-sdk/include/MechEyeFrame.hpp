/*******************************************************************************
 *BSD 3-Clause License
 *
 *Copyright (c) 2016-2022, Mech-Mind Robotics
 *All rights reserved.
 *
 *Redistribution and use in source and binary forms, with or without
 *modification, are permitted provided that the following conditions are met:
 *
 *1. Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 *
 *2. Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 *
 *3. Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 *THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 *FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ******************************************************************************/

#pragma once
#include <stdint.h>
#include <memory>
#include <vector>
#include <stdexcept>
#include "api_global.h"
#include "MechEyeDataType.h"

namespace mmind {
namespace api {

template <typename ElementType>
class Frame;

/**
 * @brief Element in DepthMap.
 */
struct ElementDepth
{
    float d; ///< Depth channel, unit: mm.
};

/**
 * @brief Element in ColorMap.
 */
struct ElementColor
{
    uint8_t b; ///< Blue channel.
    uint8_t g; ///< Green channel.
    uint8_t r; ///< Red channel.
};

/**
 * @brief Element in PointXYZMap.
 */
struct ElementPointXYZ
{
    float x; ///< X channel, unit: mm.
    float y; ///< Y channel, unit: mm.
    float z; ///< Z channel, unit: mm.
};

/**
 * @brief Element in PointXYZBGRMap.
 */
struct ElementPointXYZBGR
{
    uint8_t b; ///< Blue channel.
    uint8_t g; ///< Green channel.
    uint8_t r; ///< Red channel.
    float x;   ///< X channel, unit: mm.
    float y;   ///< Y channel, unit: mm.
    float z;   ///< Z channel, unit: mm.
};

typedef Frame<ElementColor> ColorMap;

typedef Frame<ElementDepth> DepthMap;

typedef Frame<ElementPointXYZ> PointXYZMap;

typedef Frame<ElementPointXYZBGR> PointXYZBGRMap;

/**
 * @brief Definition of data structure in device capturing image
 */
template <typename ElementType>
class Frame
{
public:
    /**
     * Constructor
     */
    Frame() : _width(0), _height(0), _pData(nullptr) {}
    /**
     * Destructor
     */
    ~Frame() {}

    /**
     * Returns the width of the Frame
     */
    inline uint32_t width() const { return _width; }

    /**
     * Returns the height of the Frame
     */
    inline uint32_t height() const { return _height; }

    /**
     * Returns true if the Frame has no elements.
     */
    inline bool empty() const { return !_pData; }

    /**
     * Returns the pointer to the element data.
     */
    inline const ElementType* data() const { return _pData.get(); }

    /**
     * Returns the pointer to the element data.
     */
    inline ElementType* data()
    {
        return const_cast<ElementType*>(static_cast<const Frame<ElementType>&>(*this).data());
    }

    /**
     * Returns a const element reference to the specified index in the Frame using the operator [].
     * @param n Index along the one dimension. It will throw an exception if the input n
     * is greater than @ref width * @ref height.
     */
    inline const ElementType& operator[](std::size_t n) const
    {
        if (n >= _height * _width || !_pData)
            throw std::out_of_range("invalid subscript");
        ElementType* data = _pData.get();
        return data[n];
    }

    /**
     * Returns a element reference to the specified index in the Frame using the operator [].
     * @param n Index along the one dimension. It will throw an exception if the input n
     * is greater than @ref width * @ref height.
     */
    inline ElementType& operator[](std::size_t n)
    {
        return const_cast<ElementType&>(static_cast<const Frame<ElementType>&>(*this)[n]);
    }

    /**
     * Returns a const element reference to the specified row and col index in the Frame.
     * @param row Index along the dimension height. It will throw an exception if the input row
     * is greater than @ref width.
     * @param col Index along the dimension width. It will throw an exception if the input col
     * is greater than @ref height.
     */
    const ElementType& at(uint32_t row, uint32_t col) const
    {
        if (row >= _height || col >= _width || !_pData)
            throw std::out_of_range("invalid subscript");
        ElementType* data = _pData.get();
        return data[row * _width + col];
    }

    /**
     * Returns a element reference to the specified row and col index in the Frame.
     * @param row Index along the dimension height. It will throw an exception if the input row
     * is greater than @ref width.
     * @param col Index along the dimension width. It will throw an exception if the input col
     * is greater than @ref height.
     */
    ElementType& at(uint32_t row, uint32_t col)
    {
        return const_cast<ElementType&>(static_cast<const Frame<ElementType>&>(*this).at(row, col));
    }

    /**
     * Change the Frame size to a new one. It will destroy the existing data and reallocate memory
     * according to the new size.
     * @param width New number of the Frame width.
     * @param height New number of the Frame height.
     */
    void resize(uint32_t width, uint32_t height)
    {
        if (_width == width && _height == height)
            return;

        _width = width;
        _height = height;
        _pData.reset(new ElementType[_width * _height], [](ElementType* p) { delete[] p; });
    }

    /**
     * Deallocated the Frame data.
     */
    void release()
    {
        _pData.reset();
        _width = 0;
        _height = 0;
    }

private:
    uint32_t _width;
    uint32_t _height;
    std::shared_ptr<ElementType> _pData;
};
} // namespace api
} // namespace mmind
